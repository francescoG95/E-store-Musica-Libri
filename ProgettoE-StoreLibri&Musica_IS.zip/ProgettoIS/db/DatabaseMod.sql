DROP DATABASE IF EXISTS DatabaseMod;
CREATE DATABASE DatabaseMod;

USE DatabaseMod;
GRANT ALL PRIVILEGES ON DatabaseMod.* TO 'DatabaseMod'@'%' IDENTIFIED BY 'DatabaseMod';



  DROP TABLE IF EXISTS utente;
CREATE TABLE utente (
 
  CodiceUtente INT AUTO_INCREMENT NOT NULL,
  Nome VARCHAR(25) ,
  Cognome VARCHAR(25) ,
  email VARCHAR(60) ,
  via   VARCHAR(30),
  n_civico INT(3),
  citta VARCHAR(30),
  username VARCHAR(30) NOT NULL,
  pass VARCHAR(30) NOT NULL,
 
 
 PRIMARY KEY ( CodiceUtente ) );
 

CREATE TABLE Ordine(
  CODICE_ORDINE INT primary key AUTO_INCREMENT,
  DATAORDINE DATE,
  MEZZO VARCHAR(45),
  NMERCI INT,
  TOTALE DECIMAL(10,2),
  METODODIPAGAMENTO VARCHAR(20),
  NUMCARD VARCHAR(23),
  
   CodiceUtente INT,
    FOREIGN KEY (CodiceUtente)
		REFERENCES utente(CodiceUtente)
		ON DELETE CASCADE
		ON UPDATE SET NULL
);



CREATE TABLE Prodotti (
	CodiceProdotto      INT NOT NULL,
    Prezzo 			    DECIMAL(8,2),
	Disponibilita 		         INT,
    Titolo               VARCHAR(30),
    Autore               VARCHAR(25),
    
    
    /* Libri */
	ISBN                    VARCHAR(14),
	
    /* CD */
    ISRC                    CHAR(12),
    
	Immagine            VARCHAR(500),
    
    Descrizione			 VARCHAR(200),
    
    CODICE_ORDINE INT, /*Non necessariamente deve esserci*/
    
    FOREIGN KEY (CODICE_ORDINE)
		REFERENCES Ordine (CODICE_ORDINE)
		ON DELETE CASCADE
		ON UPDATE SET NULL,
    
	PRIMARY KEY (CodiceProdotto)
 
);

 
 
INSERT INTO Utente(CodiceUtente, Nome, Cognome, email, via, n_civico, citta, username, pass) VALUES
(default,'Admin',NULL,NULL,NULL,NULL,NULL,'admin','admin');
INSERT INTO Prodotti(CodiceProdotto,Prezzo,Disponibilita,Titolo,Autore,ISBN,ISRC,Immagine,Descrizione,CODICE_ORDINE) VALUES(1,13,3,'UnLibro','UnAutore','123456789ASDFG',NULL,'','una descrizione',1);
INSERT INTO Prodotti(CodiceProdotto,Prezzo,Disponibilita,Titolo,Autore,ISBN,ISRC,Immagine,Descrizione,CODICE_ORDINE) VALUES (2,13,3,'UnCD','UnCantautore',NULL,123456789101,'','una descrizione',NULL);

