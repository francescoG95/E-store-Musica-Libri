package ServletUser;



import java.io.IOException;
import java.sql.SQLException;
import java.util.Collection;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import Bean.ProdottiBean;

import DataModel.ProdottiDM;

import Bean.CartBean;





public class GestioneProdotti extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private static ProdottiDM model;
	
	
	
    public GestioneProdotti() {
        super();
      
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		model= new ProdottiDM();
		String action=request.getParameter("action");
		
		response.setContentType("text/html");
		String numberPageString= request.getParameter("numberPage");
		
		if(numberPageString==null || numberPageString==""){
			numberPageString="1";
		}
		
		int numberPage=Integer.parseInt(numberPageString);
		
		if(numberPage<1){
			numberPage=1;
		}
		
		if(action!=null){
			
			if(action.equalsIgnoreCase("showlist")){

				try {
					Collection<ProdottiBean> collection=model.getAllLibri(null,numberPage);
					while(collection.isEmpty()){
						if(numberPage==1){
							break;
						}
					
					collection=model.getAllLibri(null, numberPage-1);
					}
					request.setAttribute("collection", collection);
					
				} catch (SQLException e) {
					e.printStackTrace();
				}
					
					RequestDispatcher rd= getServletContext().getRequestDispatcher("/book.jsp?numberPage="+numberPage);
					rd.forward(request, response);
			}
			
			
			
			
			
				
			else if(action.equalsIgnoreCase("showlistCD")){

					try {
						Collection<ProdottiBean> collection=model.getAllCD(null,numberPage);
						
						while(collection.isEmpty()){
							if(numberPage==1){
								break;
							}
						
						collection=model.getAllCD(null, numberPage-1);
						}
						request.setAttribute("collection", collection);
						
					} catch (SQLException e) {
						e.printStackTrace();
					}
						
						RequestDispatcher rd= getServletContext().getRequestDispatcher("/music.jsp?numberPage="+numberPage);
						rd.forward(request, response);
				}	
				
				
				
		
		
			else if (action.equalsIgnoreCase("search"))
			    {
			     String prod = request.getParameter("search");
			     
			     try {
			      Collection<ProdottiBean> prodotti = model.searchProdottoDaTitolo(prod);
			       request.setAttribute("prodotti", prodotti);
			      } catch (SQLException e) {
			      e.printStackTrace();
			     }
			     
			     
			     RequestDispatcher rd = getServletContext().getRequestDispatcher("/prodottiRicerca.jsp?numberPage=" + numberPage);
			     rd.forward(request, response);
			    }
			
		
			else if (action.equalsIgnoreCase("addToCart")){
		
				int codiceProdotto = Integer.parseInt(request.getParameter("codiceProdotto"));
				CartBean cart = (CartBean)request.getSession().getAttribute("cart");
		
					if(cart==null){
						cart= new CartBean();
					}
		
					ProdottiBean AggiungiAlCarrello = new ProdottiBean();
		

					try {
						AggiungiAlCarrello = model.searchProdottoByCodice(codiceProdotto);
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
		
					cart.addProductBean(AggiungiAlCarrello);
					request.getSession().setAttribute("cart", cart);

					RequestDispatcher rd = getServletContext().getRequestDispatcher("/cart.jsp");
					rd.forward(request, response);
		
			} 	
			
		else if(action.equalsIgnoreCase("emptyCart")){
		
		request.getSession().removeAttribute("cart");
		CartBean cart = new CartBean();
		request.getSession().setAttribute("cart", cart);

		RequestDispatcher rd = getServletContext().getRequestDispatcher("/cart.jsp");
		rd.forward(request, response);
		
	} 	else if(action.equals("deleteFromCart")){
		
		CartBean cart = (CartBean) request.getSession().getAttribute("cart");
		int codiceProdotto = Integer.parseInt(request.getParameter("codiceProdotto"));	
		
		try {
			ProdottiBean prodotto= model.searchProdottoByCodice(codiceProdotto);
			cart.deleteProdotti(prodotto);
			request.getSession().setAttribute("cart", cart);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		RequestDispatcher rd = getServletContext().getRequestDispatcher("/cart.jsp");
		rd.forward(request, response);
		
			} 
	
			}
			
		}
		
		
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		doGet(request, response);


}
}
