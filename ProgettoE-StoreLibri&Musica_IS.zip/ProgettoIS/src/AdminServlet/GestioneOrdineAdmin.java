package AdminServlet;

import java.io.IOException;
import java.sql.SQLException;
import java.util.Collection;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Bean.OrdineBean;
import DataModel.OrderDM;

/**
 * Servlet implementation class OrdersOperationsAdmin
 */

public class GestioneOrdineAdmin extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	private static OrderDM model = new OrderDM();
	
   
    public GestioneOrdineAdmin() {
        super();
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		String action = request.getParameter("action");
		boolean adminLog = (boolean) request.getSession().getAttribute("adminlog");
		boolean userLog = (boolean) request.getSession().getAttribute("userlog");
		String numberPageString= request.getParameter("numberPage");
		
		if(numberPageString==null || numberPageString==""){
			numberPageString="1";
		}
		
		int numberPage=Integer.parseInt(numberPageString);
		
		if(numberPage<1){
			numberPage=1;
		}
		
		if(userLog && adminLog){
		if((action!= null)&&(!action.equals(""))){
			
			if(action.equalsIgnoreCase("delete")){
			int code = Integer.parseInt(request.getParameter("codeOrder"));
			try {
				model.deleteOrder(code);
				RequestDispatcher rd=request.getRequestDispatcher("GestioneOrdineAdmin?action=returnAll");  
				rd.forward(request,response);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();	
			}
			
					}
			if (action.equalsIgnoreCase("returnAll")){
					Collection<OrdineBean> allOrders;
					try {
						allOrders=model.getAllOrders(numberPage);
						
						while(allOrders.isEmpty()){
							if(numberPage==1){
								break;
							}
							allOrders = model.getAllOrders(numberPage-1);
						}
						request.setAttribute("allOrders", allOrders);
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					RequestDispatcher rd=request.getRequestDispatcher("/AllOrders.jsp");  
					rd.forward(request,response);
				}	
			
			}
		}
	}
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}