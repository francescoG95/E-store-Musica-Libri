package AdminServlet;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.*;
import DataModel.UtenteDM;
import Bean.*;

/**
 * Servlet implementation class GestioneUtenteAdmin
 */

public class GestioneUtenteAdmin extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static UtenteDM model;
    /**
     * @see HttpServlet#HttpServlet()
     */
    public GestioneUtenteAdmin() {
        super();
    }
        // TODO Auto-generated constructor stub
        protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    		response.setContentType("text/html");
    		String action=request.getParameter("action");
           	model= new UtenteDM();
    		response.setContentType("text/html");
    		Collection<UtenteBean> collection = null;
    		boolean adminlog = (boolean)request.getSession().getAttribute("adminlog") ;
    		String numberPageString = (String)request.getParameter("numberPage");
    		int numberPage;
    		
    		 if(numberPageString==null||numberPageString==""){
    			 numberPageString="1";
    		 }
    		 
    		 numberPage=Integer.parseInt(numberPageString);
    		 
    		 if(numberPage<1){
    			 numberPage=1;
    		 }
    		
    		if(adminlog){
    			
    			if(action.equalsIgnoreCase("listautenti")){
    				
    				try {
    					collection = model.getUsers(numberPage);
    					while(collection.isEmpty()){
    						if(numberPage==1){
    							break;
    						}
    						collection=model.getUsers(numberPage-1);
    					}
    					request.setAttribute("allUser", collection);
    				} catch (SQLException e) {
    					e.printStackTrace();
    				}
    				RequestDispatcher rd= getServletContext().getRequestDispatcher("/ListaUtenti.jsp");
    				rd.forward(request, response);
    			}
    			else if(action.equalsIgnoreCase("delete")){
    				int Cu = Integer.parseInt(request.getParameter("CodiceUtente"));
    				if(Cu!=1){
    					try {
    						model.deleteUser(Cu);
    					} catch (SQLException e) {
    						// TODO Auto-generated catch block
    						e.printStackTrace();
    					}
    					
    					response.sendRedirect("GestioneUtenteAdmin?action=ListaUtenti");
    				
    				}
    				else{
    					//cf = null o a ""
    					response.sendError(403);
    				}
    				
    			}
    			
    			else{
    				//action diverso dalle scelte preimpostate
    				response.sendError(403);
    			}
    		}
    		else{
    			//non si � admin
    			response.sendError(401);
    		}
    		
    	}

    	/**
    	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
    	 */
    	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    		// TODO Auto-generated method stub
    		doGet(request, response);
    	}

    }