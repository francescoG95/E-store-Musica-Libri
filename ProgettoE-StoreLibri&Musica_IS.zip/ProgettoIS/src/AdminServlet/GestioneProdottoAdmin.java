package AdminServlet;


import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.sql.SQLException;
import java.util.Collection;

import javax.imageio.ImageIO;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import Bean.ProdottiBean;
import DataModel.ProdottiDM;




@MultipartConfig(fileSizeThreshold=1024*1024*5,maxFileSize=1024*1024*50, maxRequestSize=1024*1024*50)
public class GestioneProdottoAdmin extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static String SAVE_DIR="";
	private static ProdottiDM model;
  
	
	public void init(){
		SAVE_DIR = getServletConfig().getInitParameter("file-upload");
		
	}
	
    public GestioneProdottoAdmin() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		String action=(String)request.getParameter("action");
		model= new ProdottiDM();
		String numberPageString =(String)request.getParameter("numberPage");
		boolean adminlog =(boolean) request.getSession().getAttribute("adminlog");
		
		
		if(numberPageString==null || numberPageString==""){
			numberPageString="1";
		}
		
		int numberPage=Integer.parseInt(numberPageString);
		
		if(numberPage<1){
			numberPage=1;
		}
		
		/*Controllo lato admin*/
		if(adminlog){

			if(action!=null&&action!=""){
				if(action.equalsIgnoreCase("showList")){
					try {
						Collection<ProdottiBean> collection = model.getAllProdotti(null,numberPage);

						while(collection.size()==0){
							if(numberPage==1){
								break;
							}

							collection=model.getAllProdotti(null, numberPage-1);
						}
						request.setAttribute("collection", collection);
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}

					RequestDispatcher rd= getServletContext().getRequestDispatcher("/ListaProdotti.jsp?numberPage="+numberPage);
					rd.forward(request, response);


				} else if(action.equalsIgnoreCase("insert")){

					ProdottiBean prodotto= new ProdottiBean();
					String finalStringPath = null;
					
					String Titolo=request.getParameter("titolo");
					int codiceProdotto=Integer.parseInt(request.getParameter("CodiceProdotto"));
					String autore=request.getParameter("autore");
					int disponibilita=Integer.parseInt(request.getParameter("disponibilita"));
					String ISBN=request.getParameter("ISBN");
					String ISRC=request.getParameter("ISRC");
					String descrizione=request.getParameter("descrizione");
					double prezzo=Double.parseDouble(request.getParameter("prezzo"));
					
					Part part = request.getPart("image");

					if(part!=null && part.getSize()!=0){
						String savePath=request.getServletContext().getRealPath("")+SAVE_DIR;
						InputStream in;
						File fileSavePath= new File(savePath);
						if(!fileSavePath.exists()){
							fileSavePath.mkdirs();
						}
						String fileName = extractFileName(part); /*resistuisci il path completo dell'immagine*/
						fileName=fileName.substring(fileName.indexOf(File.separator,fileName.lastIndexOf(File.separator))+1, fileName.length());
						finalStringPath = savePath + File.separator + fileName;
						in=part.getInputStream();
						BufferedImage imagefinal = ImageIO.read(in);
						 
						File out = new File(finalStringPath);
						ImageIO.write(imagefinal, "jpg", out);



					}
					
					prodotto.setCodiceProdotto(codiceProdotto);
					prodotto.setTitolo(Titolo);
					prodotto.setAutore(autore);
					prodotto.setDescrizione(descrizione);
					prodotto.setPrezzo(prezzo);
					prodotto.setDisponibilit�(disponibilita);
					if(ISBN.isEmpty() || ISBN==""){
						prodotto.setISBN(null);;
					}
					else {prodotto.setISBN(ISBN);}
					if(ISRC.isEmpty() || ISRC==""){
						prodotto.setISRC(null);
					}
					else {prodotto.setISRC(ISRC);}
					
					prodotto.setImmagine(finalStringPath);


					try {
						model.insertNuovoProdotto(prodotto);
					} catch (SQLException e) {

						e.printStackTrace();
					}
					response.sendRedirect("GestioneProdottoAdmin?action=showlist&numberPage=1");

				} else if(action.equalsIgnoreCase("delete")){
					int codiceProdotto  = Integer.parseInt(request.getParameter("CodiceProdotto"));

					try {
						model.deleteProdotto(codiceProdotto);

					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					response.sendRedirect("GestioneProdottoAdmin?action=showlist&numberPage=1");

				} else if(action.equalsIgnoreCase("redirectForUpdate")){
					/*Bisogna lavorare su un solo elemento quindi si fa il redirect su altra 
					 * pagina impostando quello che � l'oggetto nella sessione*/

					int codiceProdotto= Integer.parseInt(request.getParameter("CodiceProdotto"));

					try {
						ProdottiBean prodotto = model.searchProdottoByCodice(codiceProdotto);
						request.getSession().setAttribute("prodotto", prodotto);
						/*Redirict alla pagina di modifica*/
						RequestDispatcher rd= getServletContext().getRequestDispatcher("/ModificaProdotto.jsp");
						rd.forward(request, response);
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}


				} else if(action.equalsIgnoreCase("aggiorna")){
					String finalStringPath = null;
					double prezzo=0;
					int disponibilita=0;
					ProdottiBean prodotto = new ProdottiBean();
					ProdottiBean prodottoDaAggiornare = (ProdottiBean)request.getSession().getAttribute("prodotto");
					
					
					String titolo = request.getParameter("titolo");
					
					if(request.getParameter("disponibilita")!=null || !(request.getParameter("disponibilita").equals("")) || !(request.getParameter("disponibilita").isEmpty())){
					disponibilita= Integer.parseInt(request.getParameter("disponibilita"));
					
					
					}
					String autore = request.getParameter("autore");
					String descrizione = request.getParameter("descrizione");

					if(request.getParameter("prezzo")!=null || !request.getParameter("prezzo").equals("")){
						//eccezione empty string senza questo controllo
						 prezzo = Double.parseDouble(request.getParameter("prezzo"));
					}

					String ISRC = request.getParameter("ISRC") ;
					
					String ISBN = request.getParameter("ISBN");
					Part part = request.getPart("image");
					
					if(part!=null && part.getSize()!=0){
						String savePath=request.getServletContext().getRealPath("")+SAVE_DIR;
						InputStream in;
						File fileSavePath= new File(savePath);
						if(!fileSavePath.exists()){
							fileSavePath.mkdirs();
						}
						String fileName = extractFileName(part); /*resistuisci il path completo dell'immagine*/
						fileName=fileName.substring(fileName.indexOf(File.separator,fileName.lastIndexOf(File.separator))+1, fileName.length());
						finalStringPath = savePath + File.separator + fileName;
						in=part.getInputStream();
						BufferedImage imagefinal = ImageIO.read(in);
						 
						File out = new File(finalStringPath);
						ImageIO.write(imagefinal, "jpg", out);

						prodotto.setImmagine(finalStringPath);

					}
					
					else {
						prodotto.setImmagine(null);
					}
					if(disponibilita==0){disponibilita=prodottoDaAggiornare.getDisponibilit�();}
					if(titolo.equals("") || titolo==null){titolo=prodottoDaAggiornare.getTitolo();}
					if(autore.equals("") || autore==null){autore=prodottoDaAggiornare.getAutore();}
					if(descrizione.equals("") || descrizione==null){descrizione=prodottoDaAggiornare.getDescrizione();}
					if(prezzo==0){prezzo=prodottoDaAggiornare.getPrezzo();}
					
					
					if(ISRC.equals("") || ISRC==null || ISRC.isEmpty() || ISRC.length()==0){ISRC=null;}
					else ISBN =null;

					prodotto.setCodiceProdotto(prodottoDaAggiornare.getCodiceProdotto());
					prodotto.setTitolo(titolo);
					prodotto.setAutore(autore);
					prodotto.setDescrizione(descrizione);
					prodotto.setPrezzo(prezzo);
					prodotto.setISBN(ISBN);
					prodotto.setISRC(ISRC);
					prodotto.setImmagine(finalStringPath);
					prodotto.setDisponibilit�(disponibilita);
		
					try {
						model.aggiornaProdotto(prodotto);
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}

					response.sendRedirect("GestioneProdottoAdmin?action=showlist&numberPage=1");
				}
				else{
					//action diverso dalle scelte preimpostate
					response.sendError(403);
				}
			}
			else{
				// action � uguale a null oppure a ""
				response.sendError(403);
			}
			
		} 
		else {
			//non sei admin
			response.sendError(401);
		}
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		doGet(request, response);
	}

	private String extractFileName(Part part){

		String cd=	part.getHeader("content-disposition");
		String[]items=cd.split(";");

		for(String s: items){
			if(s.trim().startsWith("filename")){
				return s.substring(s.indexOf("=")+2,s.length()-1);
			}
		}
		return "";
	}

}
