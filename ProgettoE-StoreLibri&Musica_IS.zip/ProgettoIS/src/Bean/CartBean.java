package Bean;

import java.util.ArrayList;
import java.util.List;

import Bean.ProdottiBean;;

public class CartBean {

	private List<ProdottiBean> products;
	
	public CartBean(){
		products = new ArrayList<ProdottiBean>();
	}
	
	public void addProductBean(ProdottiBean product) {
		products.add(product);
	}
	
	public void deleteProdotti(ProdottiBean product) {
		for(ProdottiBean prod : products) {
			if(prod.getCodiceProdotto() == product.getCodiceProdotto()) {
				products.remove(prod);
				break;
			}
		}
 	}
	public boolean ProdottoPresente(ProdottiBean product){
		for(ProdottiBean prod : products) {
			if(prod.getCodiceProdotto() == product.getCodiceProdotto()) {
				return true;
			}
		}
		return false;
	}

	public List<ProdottiBean> getCart() {
		return products;
	}
	
}
