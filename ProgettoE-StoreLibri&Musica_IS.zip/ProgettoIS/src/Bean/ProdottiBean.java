package Bean;

public class ProdottiBean {
	int CodiceProdotto;
	int Disponibilit�;
	double prezzo;
	String ISBN;
	String ISRC;
	String titolo;
	String autore;
	String immagine;
	String Descrizione;
	int codiceOrdine;
	
	



public ProdottiBean(){
	this.CodiceProdotto=000000000;
	this.Disponibilit�=0;
	this.prezzo=0;
	this.ISBN="";
	this.ISRC="";
	this.Descrizione="";
	this.titolo="";
	this.autore="";
	this.immagine="";
	this.codiceOrdine = 0;
}



public int getCodiceProdotto() {
	return CodiceProdotto;
}



public void setCodiceProdotto(int codiceProdotto) {
	CodiceProdotto = codiceProdotto;
}



public int getDisponibilit�() {
	return Disponibilit�;
}



public void setDisponibilit�(int disponibilit�) {
	Disponibilit� = disponibilit�;
}



public double getPrezzo() {
	return prezzo;
}



public void setPrezzo(int prezzo) {
	this.prezzo = prezzo;
}



public String getISBN() {
	return ISBN;
}



public void setISBN(String iSBN) {
	ISBN = iSBN;
}



public String getISRC() {
	return ISRC;
}



public void setISRC(String iSRC) {
	ISRC = iSRC;
}



public String getDescrizione() {
	return Descrizione;
}



public void setDescrizione(String descrizione) {
	this.Descrizione = descrizione;
}



public String getTitolo() {
	return titolo;
}



public void setTitolo(String titolo) {
	this.titolo = titolo;
}



public String getAutore() {
	return autore;
}



public void setAutore(String autore) {
	this.autore = autore;
}



public String getImmagine() {
	return immagine;
}



public void setImmagine(String immagine) {
	this.immagine = immagine;
}



public void setPrezzo(double prezzo) {
	this.prezzo = prezzo;
}

public int getCodiceOrdine() {
	return codiceOrdine;
}


public void setCodiceOrdine(int codiceOrdine) {
	this.codiceOrdine = codiceOrdine;
}




}
