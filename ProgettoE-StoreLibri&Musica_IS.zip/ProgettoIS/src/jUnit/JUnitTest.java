package jUnit;

import junit.framework.TestCase;

import static org.junit.Assert.*;

import java.sql.SQLException;
import java.util.Collection;

import org.junit.Test;

import Bean.CartBean;
import Bean.OrdineBean;
import Bean.ProdottiBean;
import Bean.UtenteBean;
import DataModel.OrderDM;
import DataModel.ProdottiDM;



public class JUnitTest {


	
	@Test
	public void TestInsertNewOrder()
	{
		OrderDM ordineDM = new OrderDM();
		OrdineBean ordineBean = new OrdineBean();
		
		ordineBean.setCodiceOrdine(1);
		ordineBean.setCodiceUtente(1);
		ordineBean.setDataOrdine("21/10/01");
		ordineBean.setMetodoDiPagamento("carta");
		ordineBean.setMezzo("corriere");
		ordineBean.setnMerci(1);
		ordineBean.setNumCard("121456595");
		
		try {
			ordineDM.insertNewOrder(ordineBean);
			assertEquals(1, ordineBean.getCodiceOrdine());
		
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void TestMyOrder() throws SQLException
	{
		OrderDM ordiniModel = new OrderDM();
		
		Collection<OrdineBean> ordiniUtenti;
		UtenteBean user = new UtenteBean();
		OrdineBean ordineBean = new OrdineBean();
		
		user.setCodiceUtente(1);		
		try {
			
			ordiniUtenti = ordiniModel.searchByCodeUser(user.getCodiceUtente(), 1);
			System.out.println(ordiniUtenti);
			assertEquals(9, ordiniUtenti.size());
			
		} catch(SQLException e)
		{
			e.printStackTrace();
		}
	}
	
	@Test
	public void TestSearchProdottoDaTitolo() {
		ProdottiDM prodottiModel = new ProdottiDM();
		
		try {
			
			Collection<ProdottiBean> prodotti = prodottiModel.searchProdottoDaTitolo("TitoloProdotto");
			assertEquals(0, prodotti.size());
			
		} catch (SQLException e) {
			
		}
	}
	
	@Test
	public void TestGetAllProdotti()
	{
		ProdottiDM prodottiModel = new ProdottiDM();
		
		try {
			Collection<ProdottiBean> collection = prodottiModel.getAllProdotti(null, 1);
			
			assertEquals(4, collection.size());
		} catch(SQLException e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void TestSearchProdottoByCodice()
	{
		ProdottiDM prodottiModel = new ProdottiDM();
		
		try {
			ProdottiBean prodotto = prodottiModel.searchProdottoByCodice(1);
			assertEquals(1, prodotto.getCodiceProdotto());
		} catch(SQLException e)
		{
			e.printStackTrace();
		}
	}
	
	public void TestGetAllLibri()
	{
		ProdottiDM prodottiModel = new ProdottiDM();
		try {
			Collection<ProdottiBean> prodotti = prodottiModel.getAllLibri(null, 1);
			assertEquals(0, prodotti.size());
		} catch(SQLException e)
		{
			e.printStackTrace();
		}
	}
	
	@Test
	public void TestInsertNuovoProdotto()
	{
		ProdottiDM prodottimodel = new ProdottiDM();
		ProdottiBean prodotto = new ProdottiBean();
		
		prodotto.setCodiceProdotto(1);
		prodotto.setTitolo("Viva l'Italia");
		prodotto.setAutore("Antonio Rossi");
		prodotto.setDescrizione("descrizione dell'Italia moderna");
		prodotto.setPrezzo(19.99);
		prodotto.setISBN("AS18AS18AS185");
		prodotto.setDisponibilit�(18);
		prodotto.setImmagine("url immagine");
		
		try {
			prodottimodel.insertNuovoProdotto(prodotto);
			assertEquals(1, 1);
		} catch(SQLException e)
		{
			e.printStackTrace();
		}
	}
	
}