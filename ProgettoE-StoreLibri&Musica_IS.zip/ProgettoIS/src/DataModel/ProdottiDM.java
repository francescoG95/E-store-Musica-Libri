package DataModel;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;



import Bean.ProdottiBean;

import ControllerDB.DriverManagerConnectionPool;





public class ProdottiDM {
	
	private final static String TABLE_NAME="DatabaseMod.Prodotti";
	
	public synchronized Collection<ProdottiBean>getAllLibri(String order, int numberPage)throws SQLException{
		
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		
		Collection<ProdottiBean> book = new LinkedList<ProdottiBean>();
		
		String getAllLibriSql="SELECT * FROM " + ProdottiDM.TABLE_NAME;

		if(order!=null){
			getAllLibriSql+=" ORDER BY "+order;
		}
			
		getAllLibriSql+=" LIMIT 9 OFFSET "+((numberPage*9)-9);
		try{
			
				
			
			connection=DriverManagerConnectionPool.getConnection();
			preparedStatement = connection.prepareStatement(getAllLibriSql);
			
			ResultSet rs=preparedStatement.executeQuery();
			
			while(rs.next()){
				
				if(rs.getString("ISRC") == null){
				ProdottiBean libro= new ProdottiBean();
				libro.setCodiceProdotto(rs.getInt("CodiceProdotto"));
				libro.setPrezzo(rs.getDouble("Prezzo"));
				libro.setDisponibilit�(rs.getInt("Disponibilita"));
				libro.setTitolo(rs.getString("Titolo"));
				libro.setAutore(rs.getString("Autore"));
				libro.setISBN(rs.getString("ISBN"));
				libro.setISRC(rs.getString("ISRC"));
				libro.setImmagine(rs.getString("Immagine"));
				libro.setDescrizione(rs.getString("Descrizione"));
				libro.setCodiceOrdine(rs.getInt("CODICE_ORDINE"));
				book.add(libro);
				}
			}
			
		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				DriverManagerConnectionPool.releaseConnection(connection);
			}

		}
		return book;
	}
	
	 public synchronized Collection<ProdottiBean> searchProdottoDaTitolo(String prod)throws SQLException{
		  Collection<ProdottiBean> prodotti = new LinkedList<ProdottiBean>();
		  ProdottiBean prodotto = new ProdottiBean();
		  Connection connection = null;
		  PreparedStatement preparedStatement = null;
		  ResultSet rs = null;
		  String sql = "SELECT * FROM "+TABLE_NAME+ " WHERE Titolo = ? ";
		  
		  
		  try{
		   connection = DriverManagerConnectionPool.getConnection();   
		   preparedStatement = connection.prepareStatement(sql);
		   preparedStatement.setString(1, prod);
		   rs = preparedStatement.executeQuery();
		   
		   if(rs.next()){prodotto.setCodiceProdotto(rs.getInt("CodiceProdotto"));
		    prodotto.setPrezzo(rs.getDouble("Prezzo"));
		    prodotto.setDisponibilit�(rs.getInt("Disponibilita"));
		    prodotto.setTitolo(rs.getString("Titolo"));
		    prodotto.setAutore(rs.getString("Autore"));
		    prodotto.setISBN(rs.getString("ISBN"));
		    prodotto.setISRC(rs.getString("ISRC"));
		    prodotto.setImmagine(rs.getString("Immagine"));
		    prodotto.setDescrizione(rs.getString("Descrizione"));
		    prodotto.setCodiceOrdine(rs.getInt("CODICE_ORDINE"));
		    prodotti.add(prodotto);
		   }
		  
		  } finally {
		   try{
		    if(connection!=null){
		     connection.close();
		    }
		   } finally {
		    DriverManagerConnectionPool.releaseConnection(connection);
		   }
		   
		  }
		  
		  return prodotti;
		 }
	
	public synchronized Collection<ProdottiBean>  getAllProdotti(String order, int numberPage)throws SQLException{
		
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		Collection<ProdottiBean> listaProdotti = new LinkedList<ProdottiBean>();
		ProdottiBean prodotto;
		ResultSet rs=null;
		String getAllProdottiSql="SELECT * FROM "+TABLE_NAME;
		
		if(order!=null){
			getAllProdottiSql+=" ORDER BY "+order;
		}
		
		getAllProdottiSql+=" LIMIT 9 OFFSET "+((numberPage*9)-9);
		
		try{
			connection=DriverManagerConnectionPool.getConnection();
			preparedStatement = connection.prepareStatement(getAllProdottiSql);
			
			rs=preparedStatement.executeQuery();
			
			while(rs.next()){
				prodotto= new ProdottiBean();
				prodotto.setCodiceProdotto(rs.getInt("CodiceProdotto"));
				prodotto.setPrezzo(rs.getDouble("Prezzo"));
				prodotto.setDisponibilit�(rs.getInt("Disponibilita"));
				prodotto.setTitolo(rs.getString("Titolo"));
				prodotto.setAutore(rs.getString("Autore"));
				prodotto.setISBN(rs.getString("ISBN"));
				prodotto.setISRC(rs.getString("ISRC"));
				prodotto.setImmagine(rs.getString("Immagine"));
				prodotto.setDescrizione(rs.getString("Descrizione"));
				prodotto.setCodiceOrdine(rs.getInt("CODICE_ORDINE"));
				listaProdotti.add(prodotto);
			}
			
		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				DriverManagerConnectionPool.releaseConnection(connection);
			}

		}
		return listaProdotti;
	}
	
	
	public synchronized ProdottiBean searchProdottoByCodice(int codiceProdotto)throws SQLException{
		ProdottiBean prodotto = new ProdottiBean();
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet rs = null;
		String sql = "SELECT * FROM "+TABLE_NAME+ " WHERE CodiceProdotto = ? ";
		
		
		try{
			connection = DriverManagerConnectionPool.getConnection();
			preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setInt(1, codiceProdotto);
			rs = preparedStatement.executeQuery();
			
			
			
			if(rs.next()){
				prodotto.setCodiceProdotto(rs.getInt("CodiceProdotto"));
				prodotto.setPrezzo(rs.getDouble("Prezzo"));
				prodotto.setDisponibilit�(rs.getInt("Disponibilita"));
				prodotto.setTitolo(rs.getString("Titolo"));
				prodotto.setAutore(rs.getString("Autore"));
				prodotto.setISBN(rs.getString("ISBN"));
				prodotto.setISRC(rs.getString("ISRC"));
				prodotto.setImmagine(rs.getString("Immagine"));
				prodotto.setDescrizione(rs.getString("Descrizione"));
				prodotto.setCodiceOrdine(rs.getInt("CODICE_ORDINE"));
			}
		
		} finally {
			try{
				if(connection!=null){
					connection.close();
				}
			} finally {
				DriverManagerConnectionPool.releaseConnection(connection);
			}
			
		}
		
		return prodotto;
	}
	
	public synchronized void insertNuovoProdotto(ProdottiBean prodotto)throws SQLException{
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		
		String sqlInsert="INSERT INTO "+TABLE_NAME+"(CodiceProdotto,Prezzo,Disponibilita,Titolo,Autore,ISBN, ISRC, Immagine, Descrizione)VALUES(?,?,?,?,?,?,?,?,?)";
		try{
			connection = DriverManagerConnectionPool.getConnection();
			preparedStatement=connection.prepareStatement(sqlInsert);
			preparedStatement.setInt(1, prodotto.getCodiceProdotto());
			preparedStatement.setDouble(2, prodotto.getPrezzo());
			preparedStatement.setInt(3, prodotto.getDisponibilit�());
			preparedStatement.setString(4, prodotto.getTitolo());
			preparedStatement.setString(5, prodotto.getAutore());
			preparedStatement.setString(6, prodotto.getISBN());
			preparedStatement.setString(7, prodotto.getISRC());
			preparedStatement.setString(8, prodotto.getImmagine());
			preparedStatement.setString(9, prodotto.getDescrizione());
			
			
			preparedStatement.executeUpdate();
			
			connection.commit();
		} finally {
			try{
				if(connection!=null){
					connection.close();
				}
			} finally {
				DriverManagerConnectionPool.releaseConnection(connection);
			}
		}
	}
	
	public synchronized boolean deleteProdotto(int codiceProdotto)throws SQLException{
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		int rs=0;
		
		String deleteSQL="DELETE FROM "+TABLE_NAME+" WHERE CodiceProdotto=?";
		
		try{
			connection = DriverManagerConnectionPool.getConnection();
			preparedStatement=connection.prepareStatement(deleteSQL);
			preparedStatement.setInt(1, codiceProdotto);
			rs=preparedStatement.executeUpdate();
			
			connection.commit();
		} finally {
			try{
				if(connection!=null){
					connection.close();
				}
			} finally {
				DriverManagerConnectionPool.releaseConnection(connection);
			}
			
		}
		
		return (rs!=0);
	}
	
	public synchronized void aggiornaProdotto(ProdottiBean prodotto)throws SQLException{
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		String updateSQL="UPDATE "+TABLE_NAME+" SET Prezzo=?, Disponibilita=?, Titolo=?, Autore=?, ISBN=?, ISRC=?, Immagine=?, Descrizione=? WHERE CodiceProdotto=?";
		try{
			connection=DriverManagerConnectionPool.getConnection();
			preparedStatement=connection.prepareStatement(updateSQL);
			
			preparedStatement.setDouble(1, prodotto.getPrezzo());
			preparedStatement.setInt(2, prodotto.getDisponibilit�());
			preparedStatement.setString(3, prodotto.getTitolo());
			preparedStatement.setString(4, prodotto.getAutore());
			preparedStatement.setString(5, prodotto.getISBN());
			preparedStatement.setString(6, prodotto.getISRC());
			preparedStatement.setString(7, prodotto.getImmagine());
			preparedStatement.setString(8, prodotto.getDescrizione());
			preparedStatement.setInt(9, prodotto.getCodiceProdotto());
			
			preparedStatement.executeUpdate();
			connection.commit();
		} finally {
			
			try{
				if(connection!=null){
					connection.close();
				}
			} finally {
				DriverManagerConnectionPool.releaseConnection(connection);
			}
		}
		
	}
	
		public synchronized Collection<ProdottiBean>getAllCD(String order, int numberPage)throws SQLException{
		
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		
		Collection<ProdottiBean> cd = new LinkedList<ProdottiBean>();
		
		String getAllCDSql="SELECT * FROM " + ProdottiDM.TABLE_NAME;
		
		
		if(order!=null){
			getAllCDSql+=" ORDER BY "+order;
		}
			
		getAllCDSql+=" LIMIT 9 OFFSET "+((numberPage*9)-9);	
		try{
			
				
			
			connection=DriverManagerConnectionPool.getConnection();
			preparedStatement = connection.prepareStatement(getAllCDSql);
			
			ResultSet rs=preparedStatement.executeQuery();
			
			while(rs.next()) {
				if (rs.getString("ISBN") == null) {
				ProdottiBean CD= new ProdottiBean();
				CD.setCodiceProdotto(rs.getInt("CodiceProdotto"));
				CD.setPrezzo(rs.getDouble("Prezzo"));
				CD.setDisponibilit�(rs.getInt("Disponibilita"));
				CD.setTitolo(rs.getString("Titolo"));
				CD.setAutore(rs.getString("Autore"));
				CD.setISBN(rs.getString("ISBN"));
				CD.setISRC(rs.getString("ISRC"));
				CD.setImmagine(rs.getString("Immagine"));
				CD.setDescrizione(rs.getString("Descrizione"));
				CD.setCodiceOrdine(rs.getInt("CODICE_ORDINE"));
				cd.add(CD);
				}
				
			}
			
			
		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				DriverManagerConnectionPool.releaseConnection(connection);
			}

		}
		return cd;
	}
}
