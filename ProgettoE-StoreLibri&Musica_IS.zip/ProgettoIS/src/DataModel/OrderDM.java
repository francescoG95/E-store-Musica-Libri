package DataModel;

import java.sql.*;
import java.util.*;

import Bean.OrdineBean;
import ControllerDB.DriverManagerConnectionPool;

public class OrderDM {

private final static String TABLE_NAME="Ordine";
	
	public synchronized void insertNewOrder(OrdineBean order) throws SQLException{
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		
		String insertSql = "INSERT INTO "+
							TABLE_NAME+" (DATAORDINE, MEZZO, NMERCI, "
							+ "TOTALE, METODODIPAGAMENTO, NUMCARD, CodiceUtente)"
							+" VALUES (?,?,?,?,?,?,?)";
		
		try {
			connection = DriverManagerConnectionPool.getConnection();
			preparedStatement = connection.prepareStatement(insertSql);
			preparedStatement.setString(1,order.getDataOrdine());
			preparedStatement.setString(2,order.getMezzo());
			preparedStatement.setInt(3,order.getnMerci());
			preparedStatement.setDouble(4,order.getTotale());
			preparedStatement.setString(5,order.getMetodoDiPagamento());
			preparedStatement.setString(6,order.getNumCard());
			preparedStatement.setInt(7, order.getCodiceUtente());	
			
			preparedStatement.executeUpdate();
			
			connection.commit();
		} finally {
			
			try{
				if(connection!=null){
					connection.close();
				}
			} finally {
				DriverManagerConnectionPool.releaseConnection(connection);
			}
			
		}	
	}
	
	public synchronized boolean deleteOrder(int codiceOrdine)throws SQLException{
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		
		int result=0;
		
		String deleteSql = "DELETE FROM "+TABLE_NAME+" WHERE CODICE_ORDINE=?";
		try{
			connection=DriverManagerConnectionPool.getConnection();
			preparedStatement=connection.prepareStatement(deleteSql);
			preparedStatement.setInt(1, codiceOrdine);
			
			result=preparedStatement.executeUpdate();
			connection.commit();
		} finally {
			
			try{
				if(connection!=null){
					connection.close();
				}
			} finally {
				DriverManagerConnectionPool.releaseConnection(connection);
			}
		}
		
	return (result!=0);
	}
	
	public synchronized OrdineBean searchByCodeOrder(int codiceOrdine)throws SQLException{
			Connection connection=null;
			PreparedStatement preparedStatement=null;
			ResultSet result=null;
			OrdineBean order= new OrdineBean();
			
			String searchSqlCodeOrder="SELECT * FROM "+TABLE_NAME+" WHERE CODICE_ORDINE=?";
		try{
			connection=DriverManagerConnectionPool.getConnection();
			preparedStatement=connection.prepareStatement(searchSqlCodeOrder);
			preparedStatement.setInt(1, codiceOrdine);
			
			result=preparedStatement.executeQuery();
			
			while(result.next()){

					order.setCodiceOrdine(result.getInt("CODICE_ORDINE"));
					order.setDataOrdine(result.getString("DATAORDINE"));
					order.setMezzo(result.getString("MEZZO"));
					order.setnMerci(result.getInt("NMERCI"));
					order.setTotale(result.getDouble("TOTALE"));
					order.setMetodoDiPagamento(result.getString("METODODIPAGAMENTO"));
					order.setNumCard(result.getString("NUMCARD"));
					order.setCodiceOrdine(result.getInt("CodiceUtente"));
				
					
			}
		} finally {
			try{
				if(connection!=null){
					connection.close();
				}
			} finally {
				DriverManagerConnectionPool.releaseConnection(connection);
			}
		}
		
		return order;
		
	}
	
	public synchronized  Collection<OrdineBean> searchByCodeUser(int CodiceUtente, int numberPage)throws SQLException{
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet result = null;
		OrdineBean order = null;
		
		Collection<OrdineBean> ordersList = new LinkedList<OrdineBean>();
		
		String searchSqlCodeUser="SELECT * FROM "+TABLE_NAME+" WHERE CodiceUtente=? ORDER BY CODICE_ORDINE";
		
		searchSqlCodeUser+=" LIMIT 9 OFFSET "+((numberPage*9)-9);
		try{
			connection=DriverManagerConnectionPool.getConnection();
			preparedStatement= connection.prepareStatement(searchSqlCodeUser);
			preparedStatement.setInt(1,CodiceUtente);
			
			result=preparedStatement.executeQuery();
			
			while(result.next()){
				order= new OrdineBean();
				order.setCodiceOrdine(result.getInt("CODICE_ORDINE"));
				order.setDataOrdine(result.getString("DATAORDINE"));
				order.setMezzo(result.getString("MEZZO"));
				order.setnMerci(result.getInt("NMERCI"));
				order.setTotale(result.getDouble("TOTALE"));
				order.setMetodoDiPagamento(result.getString("METODODIPAGAMENTO"));
				order.setNumCard(result.getString("NUMCARD"));
				order.setCodiceUtente(result.getInt("CodiceUtente"));
				ordersList.add(order);
			}
			
			
		} finally {
			try{
				if(connection!=null){
					connection.close();
				}
			} finally {
				DriverManagerConnectionPool.releaseConnection(connection);
			}
		}
		
		return ordersList;
	}
	
	public synchronized Collection<OrdineBean> getAllOrders(int numberPage)throws SQLException{
		
		Connection connection=null;
		PreparedStatement preparedStatement=null;
		ResultSet result=null;
		OrdineBean order= null;
		
		Collection<OrdineBean> ordersList = new LinkedList<OrdineBean>();
		
		String sqlGetAllOrders="SELECT * FROM "+TABLE_NAME +" ORDER BY CODICE_ORDINE";
		sqlGetAllOrders+=" LIMIT 9 OFFSET "+((numberPage*9)-9);
		try{
			connection=DriverManagerConnectionPool.getConnection();
			preparedStatement= connection.prepareStatement(sqlGetAllOrders);
			
			result=preparedStatement.executeQuery();
			
			while(result.next()){
				order = new OrdineBean();
				order.setCodiceOrdine(result.getInt("CODICE_ORDINE"));
				order.setDataOrdine(result.getString("DATAORDINE"));
				order.setMezzo(result.getString("MEZZO"));
				order.setnMerci(result.getInt("NMERCI"));
				order.setTotale(result.getDouble("TOTALE"));
				order.setMetodoDiPagamento(result.getString("METODODIPAGAMENTO"));
				order.setNumCard(result.getString("NUMCARD"));
				order.setCodiceUtente(result.getInt("CodiceUtente"));
				ordersList.add(order);
			}
			
			
		} finally {
			try{
				if(connection!=null){
					connection.close();
				}
			} finally {
				DriverManagerConnectionPool.releaseConnection(connection);
			}
		}
		
		return ordersList;
	}
	
	
}
